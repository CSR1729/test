"""Smoke test an installed AgentBuck distribution without an engine connection."""

import importlib.metadata
from importlib.resources import files

import agentbuck
from agentbuck.generated.v1 import validation_pb2, validation_pb2_grpc


assert agentbuck.__version__ == importlib.metadata.version("agentbuck")
assert (files("agentbuck") / "py.typed").is_file()
assert validation_pb2.ValidateBulkRequest is not None
assert validation_pb2_grpc.ValidationServiceStub is not None
print(f"Imported agentbuck {agentbuck.__version__} from an installed distribution")
