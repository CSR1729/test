from __future__ import annotations

import subprocess
import sys
from pathlib import Path


def main() -> int:
    repo_root = Path(__file__).resolve().parents[1]
    package_root = repo_root / "agentbuck_sdk"
    grpc_file = package_root / "agentbuck" / "generated" / "v1" / "validation_pb2_grpc.py"

    subprocess.run(
        [
            sys.executable,
            "-m",
            "grpc_tools.protoc",
            "-I",
            "proto",
            "--python_out=agentbuck/generated/v1",
            "--grpc_python_out=agentbuck/generated/v1",
            "proto/validation.proto",
        ],
        cwd=package_root,
        check=True,
    )

    generated = grpc_file.read_text()
    grpc_file.write_text(
        generated.replace(
            "import validation_pb2 as validation__pb2",
            "from . import validation_pb2 as validation__pb2",
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
