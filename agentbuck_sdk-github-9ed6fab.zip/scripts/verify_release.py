"""Check the files and metadata that will be uploaded to PyPI."""

from __future__ import annotations

import argparse
import ast
from email.parser import Parser
from pathlib import Path
import re
import tarfile
import zipfile


ROOT = Path(__file__).resolve().parents[1]


def require(condition: bool, message: str) -> None:
    if not condition:
        raise SystemExit(message)


def source_version() -> str:
    init_file = ROOT / "agentbuck_sdk" / "agentbuck" / "__init__.py"
    for node in ast.parse(init_file.read_text(encoding="utf-8")).body:
        if isinstance(node, ast.Assign) and any(
            isinstance(target, ast.Name) and target.id == "__version__"
            for target in node.targets
        ):
            value = ast.literal_eval(node.value)
            require(isinstance(value, str), "agentbuck.__version__ must be a string")
            return value
    raise SystemExit("agentbuck.__version__ was not found")


def check_metadata(raw: bytes, version: str, archive: str) -> None:
    metadata = Parser().parsestr(raw.decode("utf-8"), headersonly=True)
    require(metadata.get("Name") == "agentbuck", f"{archive}: wrong package name")
    require(metadata.get("Version") == version, f"{archive}: version does not match source")
    require(
        metadata.get("License-Expression") == "Apache-2.0",
        f"{archive}: wrong or missing SPDX license",
    )


def check_wheel(path: Path, version: str) -> None:
    with zipfile.ZipFile(path) as wheel:
        files = set(wheel.namelist())
        required = {
            "agentbuck/__init__.py",
            "agentbuck/py.typed",
            "agentbuck/generated/v1/validation_pb2.py",
            "agentbuck/generated/v1/validation_pb2_grpc.py",
            f"agentbuck-{version}.dist-info/licenses/LICENSE",
            f"agentbuck-{version}.dist-info/licenses/NOTICE",
        }
        require(required <= files, f"{path.name}: missing {sorted(required - files)}")
        metadata_path = f"agentbuck-{version}.dist-info/METADATA"
        require(metadata_path in files, f"{path.name}: missing METADATA")
        check_metadata(wheel.read(metadata_path), version, path.name)


def check_sdist(path: Path, version: str) -> None:
    prefix = f"agentbuck-{version}/"
    with tarfile.open(path, "r:gz") as sdist:
        files = set(sdist.getnames())
        required = {
            prefix + "LICENSE",
            prefix + "NOTICE",
            prefix + "agentbuck_sdk/agentbuck/py.typed",
            prefix + "agentbuck_sdk/agentbuck/generated/v1/validation_pb2.py",
            prefix + "agentbuck_sdk/agentbuck/generated/v1/validation_pb2_grpc.py",
            prefix + "agentbuck_sdk/proto/validation.proto",
            prefix + "scripts/generate_proto.py",
        }
        require(required <= files, f"{path.name}: missing {sorted(required - files)}")
        metadata_file = sdist.extractfile(prefix + "PKG-INFO")
        require(metadata_file is not None, f"{path.name}: missing PKG-INFO")
        check_metadata(metadata_file.read(), version, path.name)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("dist_dir", type=Path)
    parser.add_argument("--tag", help="release tag, for example v0.1.0")
    args = parser.parse_args()

    version = source_version()
    wheels = list(args.dist_dir.glob("agentbuck-*.whl"))
    sdists = list(args.dist_dir.glob("agentbuck-*.tar.gz"))
    require(len(wheels) == 1 and len(sdists) == 1, "Expected exactly one wheel and one sdist")

    if args.tag is not None:
        require(re.fullmatch(r"v[0-9]+\.[0-9]+\.[0-9]+", args.tag) is not None,
                f"Invalid release tag: {args.tag}")
        require(args.tag == f"v{version}", f"Tag {args.tag} does not match version {version}")

    check_wheel(wheels[0], version)
    check_sdist(sdists[0], version)
    print(f"Validated agentbuck {version} wheel and source distribution")


if __name__ == "__main__":
    main()
