"""Verify an installed SDK with CSV data against a running AgentBuck engine."""

from __future__ import annotations

import argparse
import csv
from getpass import getpass
import os
from pathlib import Path
import time

import agentbuck
from agentbuck import AgentBuckClient, AgentBuckError


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, help="CSV file to validate")
    parser.add_argument("--endpoint", help="gRPC endpoint in tcp://host:port format")
    parser.add_argument("--agent-id", default="agent-123")
    parser.add_argument("--idapp", type=int, default=370)
    args = parser.parse_args()

    csv_path = args.csv or Path(input("data (CSV path): ").strip()).expanduser()
    if not csv_path.is_file():
        raise SystemExit(f"CSV file not found: {csv_path}")

    endpoint = args.endpoint or os.getenv("AGENTBUCK_GRPC_TARGET")
    if not endpoint:
        endpoint = input("endpoint (tcp://host:port): ").strip()
    api_key = os.getenv("AGENTBUCK_API_KEY") or getpass("api_key: ")

    # The SDK uses DictReader, which excludes the header and skips blank rows.
    with csv_path.open(newline="", encoding="utf-8") as csv_file:
        rows = list(csv.DictReader(csv_file))
    if not rows:
        raise SystemExit("CSV file has no data rows")

    print(f"Using SDK from {agentbuck.__file__}")
    try:
        with AgentBuckClient(api_key=api_key, endpoint=endpoint) as client:
            start_time = time.perf_counter()
            response = client.validate_bulk(
                agent_id=args.agent_id,
                idApp=args.idapp,
                data=csv_path,
            )
            elapsed_time = time.perf_counter() - start_time
    except (AgentBuckError, OSError, TypeError, ValueError) as exc:
        raise SystemExit(f"SDK request failed: {exc}") from exc

    print(f"Time taken to get response: {elapsed_time:.3f} seconds")
    print(f"Time taken to get response: {elapsed_time * 1000:.2f} milliseconds")
    print("Status:", response.get("status"))
    print("Message:", response.get("message"))
    if response.get("status") != "success":
        raise SystemExit("Engine returned a non-success validation status")

    decisions = response.get("decisions", [])
    if not decisions:
        raise SystemExit("No decisions returned")
    if len(decisions) != len(rows):
        raise SystemExit(
            f"Cannot align rows and decisions: {len(rows)} CSV rows, "
            f"{len(decisions)} decisions"
        )

    blocked = [
        (index, row)
        for index, (row, decision) in enumerate(zip(rows, decisions), start=1)
        if decision == "BLOCK"
    ]
    if blocked:
        print("\nRows with BLOCK:")
        for index, row in blocked:
            print(f"Row {index}: {row}")
    else:
        print("No BLOCK decisions")

    print("Live SDK validation succeeded")


if __name__ == "__main__":
    main()
