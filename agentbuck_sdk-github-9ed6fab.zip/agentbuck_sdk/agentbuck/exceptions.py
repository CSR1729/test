from __future__ import annotations


class AgentBuckError(Exception):
    """Base exception for all SDK errors."""


class ConfigurationError(AgentBuckError):
    """Raised when the SDK configuration is invalid or incomplete."""


class AuthenticationError(AgentBuckError):
    """Raised when request authentication fails."""


class AuthorizationError(AgentBuckError):
    """Raised when the caller lacks permission for an operation."""


class TransportError(AgentBuckError):
    """Raised when transport communication with AgentBuck fails."""
