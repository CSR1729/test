from __future__ import annotations

from collections.abc import Sequence

from .exceptions import ConfigurationError

Metadata = Sequence[tuple[str, str]]


def api_key_metadata(api_key: str) -> Metadata:
    if api_key is None:
        raise ConfigurationError("api_key must be provided")

    normalized = api_key.strip()
    if not normalized:
        raise ConfigurationError("api_key must not be empty")

    return (("api-key", normalized),)
