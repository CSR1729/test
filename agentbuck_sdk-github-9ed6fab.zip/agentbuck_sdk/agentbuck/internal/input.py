from __future__ import annotations

import csv
from collections.abc import Iterable, Mapping
from pathlib import Path
from typing import Any, TextIO


def normalize_records(records: Any) -> list[dict[str, Any]]:
    if _is_csv_input(records):
        return _read_csv_records(records)

    dataframe_records = _records_from_dataframe_like(records)
    if dataframe_records is not None:
        return dataframe_records

    if isinstance(records, Mapping):
        mapping_records = _records_from_mapping(records)
        if mapping_records is not None:
            return mapping_records

    iterable_records = _records_from_iterable(records)
    if iterable_records is not None:
        return iterable_records

    raise TypeError(
        "records must be a CSV path/file, a DataFrame-like object, "
        "a mapping of columns, or an iterable of JSON objects"
    )


def _is_csv_input(records: Any) -> bool:
    if isinstance(records, (str, Path)):
        return str(records).lower().endswith(".csv")
    return hasattr(records, "read")


def _read_csv_records(records: str | Path | TextIO) -> list[dict[str, Any]]:
    if hasattr(records, "read"):
        return list(csv.DictReader(records))

    with open(records, newline="", encoding="utf-8") as csv_file:
        return list(csv.DictReader(csv_file))


def _records_from_dataframe_like(records: Any) -> list[dict[str, Any]] | None:
    to_dict = getattr(records, "to_dict", None)
    if not callable(to_dict):
        return None

    for kwargs in ({"orient": "records"}, {}):
        try:
            normalized = to_dict(**kwargs)
        except TypeError:
            continue

        validated = _validate_record_list(normalized)
        if validated is not None:
            return validated

        if isinstance(normalized, Mapping):
            mapping_records = _records_from_mapping(normalized)
            if mapping_records is not None:
                return mapping_records

    return None


def _records_from_mapping(records: Mapping[Any, Any]) -> list[dict[str, Any]] | None:
    if all(isinstance(value, list) for value in records.values()):
        lengths = {len(value) for value in records.values()}
        if len(lengths) > 1:
            raise TypeError("column-based input must have the same number of values")

        row_count = lengths.pop() if lengths else 0
        return [
            {str(key): records[key][index] for key in records}
            for index in range(row_count)
        ]

    if all(not isinstance(value, (list, tuple, Mapping)) for value in records.values()):
        return [dict(records)]

    return None


def _records_from_iterable(records: Any) -> list[dict[str, Any]] | None:
    if isinstance(records, (str, bytes, bytearray)):
        return None

    if not isinstance(records, Iterable):
        return None

    normalized = list(records)
    validated = _validate_record_list(normalized)
    if validated is not None:
        return validated

    return None


def _validate_record_list(records: Any) -> list[dict[str, Any]] | None:
    if not isinstance(records, list):
        return None

    if not all(isinstance(record, Mapping) for record in records):
        return None

    return [dict(record) for record in records]
