from __future__ import annotations

from collections.abc import Iterable
from typing import Any

import grpc
from google.protobuf import struct_pb2

from ..auth import Metadata
from ..exceptions import (
    AuthenticationError,
    AuthorizationError,
    TransportError,
)
from ..generated.v1 import validation_pb2, validation_pb2_grpc
from ..models import HealthResult, ValidateBulkResult


class AgentBuckTransport:
    def __init__(
        self,
        *,
        endpoint: str,
        timeout_seconds: float,
        metadata: Metadata | None = None,
    ) -> None:
        self._timeout_seconds = timeout_seconds
        self._metadata_value = metadata
        self._channel = grpc.insecure_channel(_grpc_target(endpoint))
        self._stub = validation_pb2_grpc.ValidationServiceStub(self._channel)

    def validate_bulk(
        self,
        *,
        agent_id: str,
        idApp: int,
        data: Iterable[dict[str, Any]],
    ) -> ValidateBulkResult:
        request = validation_pb2.ValidateBulkRequest(
            agent_id=agent_id,
            idApp=idApp,
            data=_data_to_proto(data),
        )
        response = self._invoke(self._stub.ValidateBulk, request)
        status = response.status
        message = response.message
        decisions = list(response.decisions) if status == "success" else []
        return {
            "status": status,
            "message": message,
            "decisions": decisions,
        }

    def health(self) -> HealthResult:
        response = self._invoke(self._stub.Health, validation_pb2.HealthRequest())
        return HealthResult(
            status=response.status,
            message=response.message,
            version=response.version,
            rules_loaded=response.rules_loaded,
        )

    def close(self) -> None:
        self._channel.close()

    def _invoke(self, rpc: Any, request: Any) -> Any:
        try:
            return rpc(
                request,
                timeout=self._timeout_seconds,
                metadata=self._metadata_value,
            )
        except grpc.RpcError as exc:
            raise _map_rpc_error(exc) from exc


def _grpc_target(endpoint: str) -> str:
    normalized = endpoint.replace("\\", "/").strip()
    if normalized.startswith("tcp://"):
        return normalized.removeprefix("tcp://")

    raise TransportError(
        "AGENTBUCK_GRPC_TARGET must use tcp://host:port format, "
        f"got: {endpoint}"
    )


def _map_rpc_error(exc: grpc.RpcError) -> TransportError:
    code = exc.code()
    details = exc.details() or "AgentBuck RPC failed"

    if code == grpc.StatusCode.UNAUTHENTICATED:
        return AuthenticationError(details)
    if code == grpc.StatusCode.PERMISSION_DENIED:
        return AuthorizationError(details)

    return TransportError(f"{code.name}: {details}")


def _data_to_proto(data: Iterable[dict[str, Any]]) -> list[struct_pb2.Struct]:
    proto_records: list[struct_pb2.Struct] = []
    for record in data:
        struct_value = struct_pb2.Struct()
        struct_value.update(record)
        proto_records.append(struct_value)
    return proto_records
