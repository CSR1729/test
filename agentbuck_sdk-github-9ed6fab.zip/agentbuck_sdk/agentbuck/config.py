from __future__ import annotations

import os
from dataclasses import dataclass

from dotenv import dotenv_values, load_dotenv

from .exceptions import ConfigurationError


@dataclass(slots=True)
class ClientConfig:
    endpoint: str


def resolve_client_config(
    *,
    endpoint: str | None,
    env_file: str | os.PathLike[str] | None = None,
) -> ClientConfig:
    resolved_endpoint = _first_non_empty(endpoint)
    if resolved_endpoint is not None:
        return ClientConfig(endpoint=resolved_endpoint)

    if env_file is not None:
        resolved_endpoint = _first_non_empty(
            dotenv_values(env_file).get("AGENTBUCK_GRPC_TARGET")
        )
    else:
        _load_default_env()
        resolved_endpoint = _first_non_empty(os.getenv("AGENTBUCK_GRPC_TARGET"))

    if resolved_endpoint is None:
        raise ConfigurationError(
            "AGENTBUCK_GRPC_TARGET must be set explicitly, in the process "
            "environment, or in an env file"
        )

    return ClientConfig(endpoint=resolved_endpoint)


def _load_default_env() -> None:
    env_path = os.path.join(os.getcwd(), ".env")
    if os.path.exists(env_path):
        load_dotenv(env_path)


def _first_non_empty(*values: str | None) -> str | None:
    for value in values:
        if value is None:
            continue

        normalized = value.strip()
        if normalized:
            return normalized

    return None
