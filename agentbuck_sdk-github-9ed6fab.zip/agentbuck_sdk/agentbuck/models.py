from __future__ import annotations

from dataclasses import dataclass
from typing import TypedDict


class ValidateBulkResult(TypedDict):
    status: str
    message: str
    decisions: list[str]


@dataclass(slots=True)
class HealthResult:
    status: str
    message: str
    version: str
    rules_loaded: bool
