"""Generated protobuf modules used by the SDK."""
