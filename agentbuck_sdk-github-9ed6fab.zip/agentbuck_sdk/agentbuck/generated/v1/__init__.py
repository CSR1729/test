"""Versioned protobuf modules for AgentBuck SDK v1."""
