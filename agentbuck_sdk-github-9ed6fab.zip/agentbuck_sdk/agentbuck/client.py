from __future__ import annotations

import os
from typing import Any

from .auth import api_key_metadata
from .config import resolve_client_config
from .internal.input import normalize_records
from .internal.transport import AgentBuckTransport
from .models import HealthResult, ValidateBulkResult


class AgentBuckClient:
    """Public Python SDK surface for bulk validation."""

    def __init__(
        self,
        *,
        api_key: str,
        timeout_seconds: float = 30.0,
        endpoint: str | None = None,
        env_file: str | os.PathLike[str] | None = None,
    ) -> None:
        config = resolve_client_config(endpoint=endpoint, env_file=env_file)

        self._transport = AgentBuckTransport(
            endpoint=config.endpoint,
            timeout_seconds=timeout_seconds,
            metadata=api_key_metadata(api_key),
        )

    def validate_bulk(
        self,
        *,
        agent_id: str,
        idApp: int,
        data: Any,
    ) -> ValidateBulkResult:
        return self._transport.validate_bulk(
            agent_id=agent_id,
            idApp=idApp,
            data=normalize_records(data),
        )

    def health(self) -> HealthResult:
        return self._transport.health()

    def close(self) -> None:
        self._transport.close()

    def __enter__(self) -> "AgentBuckClient":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()



